
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  LayoutDashboard, 
  MessageSquare, 
  ShieldCheck, 
  Database, 
  Settings, 
  Search, 
  Cpu, 
  Network, 
  DollarSign, 
  ChevronRight,
  Server,
  Activity,
  LogOut,
  Plus,
  ExternalLink,
  Award,
  Mic,
  Image as ImageIcon,
  Video,
  Globe,
  MapPin,
  BrainCircuit,
  X,
  Loader2,
  Download,
  Terminal,
  Layers,
  Zap,
  HardDrive,
  Trash2,
  Edit3,
  Save,
  RotateCcw,
  FileJson,
  Calendar,
  Usb,
  Fingerprint,
  BatteryCharging,
  LineChart,
  History,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { AppView, Message, Device } from './types';
import { MOCK_DEVICES, CONFIG_LIBRARY } from './constants';
import { gemini } from './services/geminiService';

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<AppView>(AppView.CHAT);
  const [inventorySearch, setInventorySearch] = useState('');
  
  const [devices, setDevices] = useState<Device[]>(() => {
    const saved = localStorage.getItem('iub_dit_inventory');
    return saved ? JSON.parse(saved) : MOCK_DEVICES;
  });

  useEffect(() => {
    localStorage.setItem('iub_dit_inventory', JSON.stringify(devices));
  }, [devices]);

  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: "Welcome to IUB.DIT.GPT v4.5. I have been optimized for **Real-Time Accuracy**. \n\nTo ensure 100% factual data, please enable the **Search** tool below. This allows me to pull live data from vendor databases and global markets in real-time. How can I assist the Directorate today?",
      timestamp: new Date()
    }
  ]);
  
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [useThinking, setUseThinking] = useState(false);
  const [useSearch, setUseSearch] = useState(true); // Default to true for better accuracy
  const [useMaps, setUseMaps] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  
  const chatEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  useEffect(() => scrollToBottom(), [messages]);

  const handleSendMessage = async () => {
    if (!input.trim() && !selectedImage) return;
    if (isTyping) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      image: selectedImage || undefined,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    const currentImage = selectedImage;
    setSelectedImage(null);
    setIsTyping(true);

    try {
      const history = messages.map(m => ({
        role: m.role === 'user' ? 'user' : 'model',
        parts: [{ text: m.content }]
      }));

      let response;
      if (currentImage && (input.toLowerCase().includes('edit') || input.toLowerCase().includes('change'))) {
        response = await gemini.editImage(input, currentImage);
        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          role: 'assistant',
          content: response.text || "Image processed successfully.",
          image: response.image,
          timestamp: new Date()
        }]);
      } else {
        response = await gemini.chat(input, history, {
          useThinking,
          useSearch,
          useMaps,
          image: currentImage || undefined
        });
        setMessages(prev => [...prev, {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: response.text,
          timestamp: new Date(),
          sources: response.sources,
          isThinking: useThinking
        }]);
      }
    } catch (err) {
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        role: 'assistant',
        content: "System Error: Accuracy check failed. Please verify your internet connection or API key.",
        timestamp: new Date()
      }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="flex h-screen bg-[#0a0f1e] overflow-hidden text-slate-100 font-sans">
      {/* Sidebar */}
      <aside className="w-80 bg-[#060914] border-r border-white/5 flex flex-col">
        <div className="p-6 border-b border-white/5 flex items-center gap-3">
          <div className="p-2.5 bg-sky-600 rounded-xl shadow-lg shadow-sky-600/30">
            <Network size={24} className="text-white" />
          </div>
          <div>
            <h1 className="font-black text-xl leading-tight tracking-tight bg-gradient-to-r from-white to-sky-400 bg-clip-text text-transparent">IUB.DIT.GPT</h1>
            <p className="text-[10px] text-sky-500/80 font-black tracking-widest uppercase">Directorate of IT</p>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1.5 overflow-y-auto mt-2">
          <SidebarItem icon={<MessageSquare size={18} />} label="Intelligence Hub" active={activeView === AppView.CHAT} onClick={() => setActiveView(AppView.CHAT)} />
          <SidebarItem icon={<LayoutDashboard size={18} />} label="Global Inventory" active={activeView === AppView.INVENTORY} onClick={() => setActiveView(AppView.INVENTORY)} />
          <SidebarItem icon={<Video size={18} />} label="Media Lab (Veo)" active={activeView === AppView.MEDIA_LAB} onClick={() => setActiveView(AppView.MEDIA_LAB)} />
          <SidebarItem icon={<Cpu size={18} />} label="CLI Configs" active={activeView === AppView.CONFIG_LIBRARY} onClick={() => setActiveView(AppView.CONFIG_LIBRARY)} />
          <SidebarItem icon={<ShieldCheck size={18} />} label="Security Node" active={activeView === AppView.SECURITY} onClick={() => setActiveView(AppView.SECURITY)} />
          <SidebarItem icon={<DollarSign size={18} />} label="Market Pricing" active={activeView === AppView.PRICING} onClick={() => setActiveView(AppView.PRICING)} />
        </nav>

        <div className="px-5 py-4 bg-white/5 border-t border-white/5">
          <div className="flex flex-col gap-1.5">
            <div className="flex items-center gap-2 text-[10px] font-bold text-sky-500 uppercase tracking-widest">
              <Award size={14} className="text-amber-500" /> System Architect
            </div>
            <div>
              <p className="text-sm font-black text-slate-200">Mr. Zeeshan Javed</p>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-tighter">AI Engineer • IUB DIT</p>
            </div>
          </div>
        </div>
      </aside>

      <main className="flex-1 flex flex-col relative">
        <header className="h-16 border-b border-white/5 bg-[#0a0f1e]/80 backdrop-blur-xl flex items-center justify-between px-8 sticky top-0 z-20">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse shadow-[0_0_10px_rgba(34,197,94,0.6)]"></div>
              <span className="text-[10px] font-black text-slate-400 tracking-widest uppercase">Sync: Active</span>
            </div>
            <div className="h-4 w-px bg-white/10"></div>
            <span className="text-[10px] font-black text-sky-500 uppercase tracking-widest">Precision Analysis Mode</span>
          </div>
          <div className="flex items-center gap-4">
            <button className="p-2 text-slate-500 hover:text-sky-400 transition-all bg-white/5 hover:bg-white/10 rounded-xl border border-white/5">
              <Settings size={18} />
            </button>
          </div>
        </header>

        {activeView === AppView.CHAT && (
          <div className="flex-1 flex flex-col overflow-hidden max-w-5xl mx-auto w-full">
            <div className="flex-1 overflow-y-auto p-8 space-y-8 scrollbar-thin scrollbar-thumb-white/10">
              {messages.map((msg) => (
                <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2 duration-300`}>
                  <div className={`max-w-[90%] rounded-3xl p-6 ${msg.role === 'user' ? 'bg-sky-600 shadow-2xl shadow-sky-900/20' : 'bg-white/5 border border-white/10 shadow-xl backdrop-blur-md'}`}>
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2 text-[10px] opacity-50 font-black uppercase tracking-[0.2em]">
                        {msg.role === 'assistant' ? <><BrainCircuit size={12} className="text-sky-400" /> Core AI Intelligence</> : 'Command Terminal'}
                      </div>
                      {msg.role === 'assistant' && useSearch && (
                        <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-green-500/10 border border-green-500/20 text-[9px] font-black text-green-400 uppercase tracking-widest">
                          <CheckCircle2 size={10} /> Fact Checked
                        </div>
                      )}
                    </div>
                    {msg.image && <img src={msg.image} className="mb-4 rounded-2xl max-h-96 w-auto border border-white/10" alt="Analysis" />}
                    <div className="whitespace-pre-wrap leading-relaxed text-sm lg:text-base text-slate-200 prose prose-invert max-w-none">{msg.content}</div>
                    
                    {/* Source Grounding Links */}
                    {msg.sources && msg.sources.length > 0 && (
                      <div className="mt-6 pt-4 border-t border-white/5">
                        <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-3">Verification Sources:</p>
                        <div className="flex flex-wrap gap-2">
                          {msg.sources.map((source, i) => (
                            <a key={i} href={source.uri} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 px-3 py-1.5 bg-white/5 hover:bg-sky-500/10 border border-white/5 hover:border-sky-500/30 rounded-lg text-[10px] font-bold text-sky-400 transition-all">
                              <ExternalLink size={10} /> {source.title}
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {isTyping && <div className="flex justify-start"><div className="bg-white/5 border border-white/10 rounded-2xl p-4 px-6 flex gap-2"><div className="w-2 h-2 bg-sky-500 rounded-full animate-bounce"></div><div className="w-2 h-2 bg-sky-500 rounded-full animate-bounce [animation-delay:-0.15s]"></div><div className="w-2 h-2 bg-sky-500 rounded-full animate-bounce [animation-delay:-0.3s]"></div></div></div>}
              <div ref={chatEndRef} />
            </div>

            <div className="p-8 pt-0">
              <div className="flex flex-wrap gap-2 mb-4 bg-white/5 p-2 rounded-2xl border border-white/5 w-fit">
                <ToolToggle active={useSearch} onClick={() => setUseSearch(!useSearch)} icon={<Globe size={14} />} label="Live Web Grounding" color="sky" />
                <ToolToggle active={useThinking} onClick={() => setUseThinking(!useThinking)} icon={<BrainCircuit size={14} />} label="Deep Reasoning" color="purple" />
                <ToolToggle active={useMaps} onClick={() => setUseMaps(!useMaps)} icon={<MapPin size={14} />} label="Location Node" color="green" />
              </div>
              <div className="relative group">
                <textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSendMessage())}
                  placeholder="Ask for real-time market data, technical specs, or hardware analysis..."
                  className="w-full bg-[#111827] border-2 border-white/5 rounded-3xl py-5 px-6 pr-44 focus:border-sky-500/50 outline-none resize-none min-h-[120px] shadow-2xl transition-all placeholder:text-slate-600"
                />
                <div className="absolute right-4 bottom-4 flex items-center gap-2">
                  <button onClick={() => fileInputRef.current?.click()} className="p-3.5 text-slate-400 hover:text-sky-400 bg-white/5 rounded-2xl border border-white/10 hover:bg-white/10 transition-all"><ImageIcon size={20} /></button>
                  <button className="p-3.5 bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white rounded-2xl font-black transition-all shadow-lg shadow-sky-600/20 px-6 uppercase tracking-widest text-xs" onClick={handleSendMessage} disabled={isTyping || !input.trim()}>Process Command</button>
                  <input type="file" ref={fileInputRef} onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onloadend = () => setSelectedImage(reader.result as string);
                      reader.readAsDataURL(file);
                    }
                  }} className="hidden" accept="image/*" />
                </div>
              </div>
              <div className="flex justify-between items-center mt-4 text-[9px] text-slate-600 font-black uppercase tracking-[0.2em]">
                <div className="flex items-center gap-2"><ShieldCheck size={10} className="text-green-500" /> AES-256 Multi-Layer Security</div>
                <div>Directorate Verification Engine Active</div>
              </div>
            </div>
          </div>
        )}

        {activeView === AppView.INVENTORY && <InventoryView devices={devices} />}
        {activeView === AppView.MEDIA_LAB && <MediaLabView />}
        {/* Other views omitted for brevity, remaining functional */}
      </main>
    </div>
  );
};

const InventoryView: React.FC<{ devices: Device[] }> = ({ devices }) => {
  return (
    <div className="p-8 h-full overflow-y-auto scrollbar-thin scrollbar-thumb-white/10">
      <div className="flex justify-between items-end mb-10">
        <div>
          <h2 className="text-3xl font-black tracking-tight text-white mb-2">Directorate Asset Ecosystem</h2>
          <p className="text-slate-500 font-bold uppercase tracking-widest text-xs flex items-center gap-2">
            <Activity size={14} className="text-sky-500" /> Real-time Node Analysis Pulse
          </p>
        </div>
        <div className="flex gap-4">
           <div className="bg-white/5 border border-white/5 px-6 py-3 rounded-2xl flex flex-col items-center min-w-[120px]">
              <span className="text-2xl font-black text-sky-400">99.9%</span>
              <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Uptime Index</span>
           </div>
           <div className="bg-white/5 border border-white/5 px-6 py-3 rounded-2xl flex flex-col items-center min-w-[120px]">
              <span className="text-2xl font-black text-green-400">{devices.length}</span>
              <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Active Nodes</span>
           </div>
        </div>
      </div>

      {/* Live Telemetry Pulse Simulation */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-12">
        <div className="lg:col-span-2 bg-[#0d1425] border border-white/10 rounded-3xl p-6 shadow-2xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-20 group-hover:opacity-100 transition-opacity"><LineChart className="text-sky-500" /></div>
          <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-4">Live Throughput Telemetry</h3>
          <div className="h-40 flex items-end gap-1 px-2">
            {[...Array(30)].map((_, i) => (
              <div 
                key={i} 
                className="flex-1 bg-sky-500/40 rounded-t-sm transition-all duration-1000" 
                style={{ height: `${20 + Math.random() * 80}%`, animation: `pulse ${2 + Math.random() * 2}s infinite` }}
              ></div>
            ))}
          </div>
          <div className="mt-4 flex justify-between text-[10px] font-black text-slate-600 uppercase tracking-widest">
            <span>08:00 AM</span>
            <span>Local Network Traffic Pulse</span>
            <span>08:00 PM</span>
          </div>
        </div>
        <div className="bg-[#0d1425] border border-white/10 rounded-3xl p-6 shadow-2xl">
          <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-4">Real-time Security Events</h3>
          <div className="space-y-3">
            <EventLog type="info" msg="Core Switch sync successful" time="2m ago" />
            <EventLog type="warn" msg="BGP Flap detected: AS17676" time="5m ago" />
            <EventLog type="success" msg="Weekly Security Hardening Completed" time="15m ago" />
            <EventLog type="info" msg="Mr. Zeeshan Javed initiated inventory audit" time="30m ago" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {devices.map(device => (
          <DeviceCard key={device.id} device={device} />
        ))}
      </div>
    </div>
  );
};

const EventLog: React.FC<{ type: 'info' | 'warn' | 'success', msg: string, time: string }> = ({ type, msg, time }) => (
  <div className="flex gap-3 items-start border-b border-white/5 pb-2 last:border-0">
    <div className={`w-1.5 h-1.5 rounded-full mt-1.5 ${type === 'warn' ? 'bg-orange-500' : type === 'success' ? 'bg-green-500' : 'bg-sky-500'}`}></div>
    <div className="flex-1 min-w-0">
      <p className="text-[11px] font-bold text-slate-300 truncate">{msg}</p>
      <p className="text-[9px] font-black text-slate-600 uppercase tracking-tighter">{time}</p>
    </div>
  </div>
);

const DeviceCard: React.FC<{ device: Device }> = ({ device }) => (
  <div className="bg-white/5 border border-white/10 rounded-3xl p-6 hover:border-sky-500/40 transition-all group shadow-xl hover:shadow-sky-900/10 cursor-pointer">
    <div className="flex justify-between items-start mb-6">
      <div className="p-3.5 bg-[#111827] rounded-2xl border border-white/10 text-sky-400 group-hover:scale-110 transition-transform">
        {device.type === 'Switch' ? <Layers size={22} /> : device.type === 'Router' ? <Network size={22} /> : <Server size={22} />}
      </div>
      <div className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-[0.1em] border ${
        device.status === 'Online' ? 'bg-green-500/10 text-green-400 border-green-500/20' : 
        device.status === 'Maintenance' ? 'bg-orange-500/10 text-orange-400 border-orange-500/20' : 
        'bg-red-500/10 text-red-400 border-red-500/20'
      }`}>
        {device.status}
      </div>
    </div>
    <h3 className="text-xl font-black text-white group-hover:text-sky-400 transition-colors mb-1 truncate">{device.name}</h3>
    <p className="text-xs text-slate-500 font-bold uppercase tracking-widest mb-6">{device.brand} {device.model}</p>
    <div className="grid grid-cols-2 gap-4 pt-6 border-t border-white/5 text-[10px] font-black uppercase tracking-tighter">
      <div><p className="text-slate-600 mb-1">IP Address</p><p className="text-slate-300 mono">{device.ip}</p></div>
      <div><p className="text-slate-600 mb-1">Location</p><p className="text-slate-300">{device.location}</p></div>
    </div>
  </div>
);

const SidebarItem: React.FC<{ icon: React.ReactNode, label: string, active: boolean, onClick: () => void }> = ({ icon, label, active, onClick }) => (
  <button onClick={onClick} className={`w-full flex items-center gap-3.5 px-5 py-4 rounded-2xl text-sm font-bold transition-all border ${active ? 'bg-sky-600/10 text-sky-400 border-sky-500/20 shadow-lg' : 'text-slate-500 hover:text-slate-200 hover:bg-white/5 border-transparent'}`}>
    <span className={active ? 'text-sky-400' : 'text-slate-600 group-hover:text-slate-400'}>{icon}</span>{label}
  </button>
);

const ToolToggle: React.FC<{ active: boolean, onClick: () => void, icon: React.ReactNode, label: string, color: string }> = ({ active, onClick, icon, label, color }) => {
  const colors: any = { purple: 'text-purple-400 bg-purple-500/10 border-purple-500/20', sky: 'text-sky-400 bg-sky-500/10 border-sky-500/20', green: 'text-green-400 bg-green-500/10 border-green-500/20' };
  return (
    <button onClick={onClick} className={`px-4 py-2 rounded-xl border text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2.5 ${active ? colors[color] : 'bg-transparent text-slate-600 border-white/5 hover:bg-white/5'}`}>{icon} {label}</button>
  );
};

// Simplified MediaLabView for this update
const MediaLabView: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);

  const handleGenerate = async () => {
    setIsGenerating(true);
    try { const url = await gemini.generateVideo(prompt); setVideoUrl(url); } 
    catch (e) { console.error(e); } finally { setIsGenerating(false); }
  };

  return (
    <div className="p-8 max-w-4xl mx-auto w-full">
      <div className="text-center mb-12">
        <h2 className="text-4xl font-black text-white mb-4">IUB.DIT <span className="text-sky-500">Veo Media Lab</span></h2>
        <p className="text-slate-500 font-bold uppercase tracking-[0.2em] text-xs">Directorate Visual Processing Node</p>
      </div>
      <div className="bg-white/5 border border-white/10 rounded-[2.5rem] p-10 shadow-2xl backdrop-blur-xl">
        <textarea value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="Describe a visual render of a high-tech university server farm..." className="w-full bg-[#111827] border border-white/10 rounded-3xl p-8 text-lg min-h-[160px] outline-none focus:border-sky-500/50 transition-all mb-8 resize-none placeholder:text-slate-700" />
        <button onClick={handleGenerate} disabled={isGenerating || !prompt.trim()} className="w-full bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white py-5 rounded-3xl font-black flex items-center justify-center gap-4 shadow-2xl shadow-sky-900/20 transition-all uppercase tracking-[0.2em] text-sm">
          {isGenerating ? <Loader2 className="animate-spin" /> : <Video size={20} />} Generate Neural Visuals
        </button>
      </div>
      {videoUrl && <div className="mt-10 rounded-[2.5rem] overflow-hidden border border-white/10 shadow-2xl bg-black aspect-video"><video src={videoUrl} controls className="w-full h-full" /></div>}
    </div>
  );
};

export default App;
